#include<iostream>  //calling liberaries
#include<cmath> //for maths
#include<string> //for string inputs
#include<ctime>
#include<cstdlib>
#include<iomanip>

using namespace std;
int main(){ 

string sen;
cout<<"Enter string: ";
cin>>sen;

for (char i='A'; i<='Z';i++){

   for (char j='a'; i<='z';j++){
    cout<<j;
   }
cout<<i;
    
}
   
  return 0;
}
