#include <iostream>
using namespace std;

int main(){

    char d;
    char e;
    char f;
    char g;
    char h;
    
    cin>> d;
    cin>> e;
    cin>> f;
    cin>> g;
    cin>> h;
   
    
    cout << "---------------ASCII Table for escape sequesnces--------------- "<<endl;
    cout << "  " <<endl;
    cout << "Escape sequence              Decimal Val         Hexcadecimal Value" <<endl;
    cout << "  " <<endl;
    cout << "  " <<endl;

  
    cout << "ASCII Value of "<< d <<" is"<<"            "<<int(d)<<"                   " <<hex<<int(d)<<endl;
    cout << "ASCII Value of "<< e <<" is"<<"            "<<int(e)<<"                   " <<hex<<int(e)<<endl;
    cout << "ASCII Value of "<< f <<" is"<<"            "<<int(f)<<"                   " <<hex<<int(f)<<endl;
    cout << "ASCII Value of "<< g <<" is"<<"            "<<int(g)<<"                   " <<hex<<int(g)<<endl;
    cout << "ASCII Value of "<< h <<" is"<<"            "<<int(h)<<"                   " <<hex<<int(h)<<endl;
    
   
    // cout << char(d)<<endl;
    // cout << "ASCII Value of tab is ";
    
    // cout << char(d)<<endl;
    // cout << "ASCII Value of tab is  ";
    
    // cout << char(d) <<endl;
    // cout << "ASCII Value of tab is  ";
   
    // cout << char(d)<<endl;

 
    return 0;
}

