#include<iostream>
#include<cmath>
using namespace std;


void replace(string sen, string find, string rep){


if (string sen.length()==0){
     return "";      
}
else{
    for(int i=1; i<=sen.length(), i++){
        search =
    }
    if found{
        return rep+replace(sen.substr(rep.length()+1, ))
    }

    return
}

}



return;
}






int main(){

    replace();
    return 0;
}